<?php

class Apptha_Gethelook_Model_Gethelook extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("gethelook/gethelook");

    }

}
	 