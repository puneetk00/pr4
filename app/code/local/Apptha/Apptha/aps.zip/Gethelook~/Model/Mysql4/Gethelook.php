<?php
class Apptha_Gethelook_Model_Mysql4_Gethelook extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("gethelook/gethelook", "id");
    }
}