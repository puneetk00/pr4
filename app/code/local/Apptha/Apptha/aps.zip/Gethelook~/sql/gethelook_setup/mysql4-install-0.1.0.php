<?php
// $installer = $this;
// $installer->startSetup();
// $sql=<<<SQLTEXT
// create table get_the_look(id int not null auto_increment, 
// name varchar(100), 
// image1 varchar(100), 
// image2 varchar(100), 
// image3 varchar(100), 
// image4 varchar(100), 
// image5 varchar(100), 
// image6 varchar(100), 
// image7 varchar(100), 
// primary key(id)
// );
// SQLTEXT;

// $installer->run($sql);
// demo 
// Mage::getModel('core/url_rewrite')->setId(null);
// demo 
// $installer->endSetup();
	 